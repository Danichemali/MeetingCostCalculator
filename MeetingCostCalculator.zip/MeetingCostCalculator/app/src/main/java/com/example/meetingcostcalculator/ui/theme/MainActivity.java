package com.example.meetingcostcalculator.ui.theme;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.meetingcostcalculator.R;

public class MainActivity extends AppCompatActivity {
    private EditText salaryInput, durationInput;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        salaryInput = findViewById(R.id.salaryInput);
        durationInput = findViewById(R.id.durationInput);
        resultText = findViewById(R.id.resultText);
        Button calculateButton = findViewById(R.id.calculateButton);

        calculateButton.setOnClickListener(v -> calculateCost());
    }

    private void calculateCost() {
        String salaryStr = salaryInput.getText().toString();
        String durationStr = durationInput.getText().toString();

        if (salaryStr.isEmpty() || durationStr.isEmpty()) {
            resultText.setText("Please enter both values");
            return;
        }

        double salary = Double.parseDouble(salaryStr);
        int duration = Integer.parseInt(durationStr);
        double cost = salary * (duration / 60.0);
        resultText.setText(String.format("Total cost: $%.2f", cost));
    }
}